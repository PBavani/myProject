package com.pack.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pack.Dao.UserDao;
import com.pack.Model.User;



/**
 * Servlet implementation class UserServlet
 */
@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	UserDao userDao=new UserDao();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getParameter("action");
		System.out.println(action);
		switch(action)
		{
		case "add":
			insert(request,response);
		    break;
		case "update":
			update(request,response);
			break;
		case "delete":
			delete(request,response);
		    break;
//		case "view":
//			view(request,response);
//			 break;
//		}
		} 
	}
    
    protected void insert(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  	  User  user=new User();
  	  
  
  	user.setEmail(request.getParameter("email"));
  	user.setPassword(request.getParameter("password"));
  	user.setDepartment(request.getParameter("department"));
  	user.setAddress(request.getParameter("address"));
  	user.setPhoneNumber(request.getParameter("phoneNumber"));
  			 
  
  int i = userDao.add(user);
    
    if(i>0){
    	response.sendRedirect("usersuccess.jsp");
    }  
    	   else{ response.sendRedirect("userfailure.jsp");
    	 
    	}
    } 
    
    protected void update(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 
		 
		 
		
    	  User  user=new User();
		  System.out.println("in update of servlet");
		  user.setCorporateId(Integer.parseInt(request.getParameter("corporate_id")));
		  user.setDepartment(request.getParameter("department"));
		  	user.setAddress(request.getParameter("address"));
		  	user.setPhoneNumber(request.getParameter("phoneNumber"));
		  
		  System.out.println("in servlet  "+ user.getCorporateId()+"  "+ user.getDepartment()+" "+ user.getAddress()+" "+ user.getPhoneNumber());
		  
		  int i = userDao.update(user);
		    
		    if(i>0){
		    	response.sendRedirect("updatesuccess.jsp");
		    }  
		    	   else{ response.sendRedirect("updatefailure.jsp");
		    	 
		    	}
		    } 
    
    protected void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
   	 
    	int id=Integer.parseInt(request.getParameter("id"));
    	
    	 System.out.println("id is "+id);
    	int i=userDao.delete(id);
    	  if(i>0){
		    	response.sendRedirect("deletesuccess.jsp");
		    }  
		    	   else{ response.sendRedirect("deletefailure.jsp");
		    	 
		    	}
		    } 
    		 

    }
   

	