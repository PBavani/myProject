package com.pack.Dao;

import java.sql.*;

import com.pack.Controller.UserLoginBean;



public class ChangePasswordDao {
	private String dbUrl="jdbc:mysql://localhost:3306/project";
	private String dbUname="root";
	private String dbPassword="Tiger@2325";
	private String dbDriver="com.mysql.jdbc.Driver";
	
	public void loadDriver(String dbDriver)
	{
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public Connection getConnection()
	{
		Connection con=null;
		try {
			con=DriverManager.getConnection(dbUrl,dbUname,dbPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
	
	

	public int ChangePasswordDAO(UserLoginBean userloginbean) {
		// TODO Auto-generated method stub
		int result=0;
		
		loadDriver(dbDriver);
	    Connection con =getConnection();
	    String sql="UPDATE CorporateUser SET NewPassword=? WHERE OldPassword=?";
	    
	    PreparedStatement ps;
	    try {
	    	ps=con.prepareStatement(sql);
	    	ps.setString(1, userloginbean.getNewPassword());
			ps.setString(2, userloginbean.getOldPassword());
			
			result=ps.executeUpdate(); 
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	    System.out.println("dao"+result);
	    
	    return result;
	}

}
