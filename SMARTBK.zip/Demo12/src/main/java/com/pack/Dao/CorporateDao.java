package com.pack.Dao;
import com.pack.Model.Corporate;
import com.pack.Model.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;



public class CorporateDao {
	 
	public   int add(Corporate co){
		int status=0;
		try{
			Connection con=MySqlConn.getCon();
			PreparedStatement ps=con.prepareStatement("insert into  corporate(corporate_id,corporateName,address,phoneNumber)  values(?,?,?,?)");
		 
			ps.setInt(1,co.getCorporateId());
		 	ps.setString(2,co.getCorporateName());
			ps.setString(3,co.getAddress());
			ps.setString(4,co.getPhoneNumber());
			status=ps.executeUpdate();
		}catch(Exception e){System.out.println(e);}
		return status;
		
		
	}
	public   int update(Corporate co){
		 
		int status=0;
		try{
			Connection con=MySqlConn.getCon();
			
			PreparedStatement ps=con.prepareStatement("update corporate set address=?,phoneNumber=? where corporate_id=?");
			System.out.println("id=  "+co.getAddress()+" "+co.getPhoneNumber()+" "+co.getCorporateId());
			
			ps.setString(1,co.getAddress());
			ps.setString(2,co.getPhoneNumber());
			ps.setInt(3,co.getCorporateId());
			
			status=ps.executeUpdate();
		}catch(Exception e){System.out.println(e);}
		return status;


	}

	
	
	

	public   int delete(int id){
		int status=0;
		try{
			Connection con=MySqlConn.getCon();
			PreparedStatement ps=con.prepareStatement("delete from corporate where corporate_id=?");
			ps.setInt(1,id);
			status=ps.executeUpdate();
		}catch(Exception e){System.out.println(e);}

		return status;
	}
	
	}


 

