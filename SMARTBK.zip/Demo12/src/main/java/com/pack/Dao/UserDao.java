package com.pack.Dao;

import com.pack.Model.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;



public class UserDao {
	 
	public   int add(User u){
		int status=0;
		try{
			Connection con=MySqlConn.getCon();
			PreparedStatement ps=con.prepareStatement("insert into user(corporate_id,email,password,department,address,phonenumber)  values(?,?,?,?,?,?)");
		 
			ps.setInt(1,u.getCorporateId());
		 	ps.setString(2,u.getEmail());
			ps.setString(3,u.getPassword());
			ps.setString(4,u.getDepartment());
			ps.setString(5,u.getAddress());
			ps.setString(6,u.getPhoneNumber());
			status=ps.executeUpdate();
		}catch(Exception e){System.out.println(e);}
		return status;
		
		
	}
	public   int update(User u){
		 
		int status=0;
		try{
			Connection con=MySqlConn.getCon();
			
			PreparedStatement ps=con.prepareStatement("update user set department=?,address=?,phoneNumber=? where corporate_id=?");
			System.out.println("id= "+u.getDepartment()+" "+u.getAddress()+" "+u.getPhoneNumber()+" "+u.getCorporateId());
			
			ps.setString(1,u.getDepartment());
			ps.setString(2,u.getAddress());
			ps.setString(3,u.getPhoneNumber());
			ps.setInt(4,u.getCorporateId());
			
			status=ps.executeUpdate();
		}catch(Exception e){System.out.println(e);}
		return status;


	}


	public   int delete(int id){
		int status=0;
		try{
			Connection con=MySqlConn.getCon();
			PreparedStatement ps=con.prepareStatement("delete from user where corporate_id=?");
			ps.setInt(1,id);
			status=ps.executeUpdate();
		}catch(Exception e){System.out.println(e);}

		return status;
	}
	
	}
	 

