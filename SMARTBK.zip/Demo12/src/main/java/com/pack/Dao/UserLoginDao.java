package com.pack.Dao;

import java.sql.*;

import com.pack.Controller.UserLoginBean;



public class UserLoginDao {
	private String dbUrl="jdbc:mysql://localhost:3306/project";
	private String dbUID="root";
	private String dbPassword="Tiger@2325";
	private String dbDriver="com.mysql.jdbc.Driver";
	
	public void loadDriver(String dbDriver)
	{
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public Connection getConnection()
	{
		Connection con=null;
		try {
			con=DriverManager.getConnection(dbUrl,dbUID,dbPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
	
	public boolean FirstLogin(UserLoginBean userloginBean) {
		loadDriver(dbDriver);
	    Connection con =getConnection();
	    boolean status=false;
	    String sql="SELECT * FROM user where email=? and password= ?";
	    
	    PreparedStatement ps;
	    try {
	    	ps=con.prepareStatement(sql);
			ps.setString(1, userloginBean.getUserId());
			ps.setString(2, userloginBean.getOldPassword());
			
			ResultSet rs =ps.executeQuery();
//			System.out.println("First Login:"+rs.next());
			status=rs.next();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    System.out.println("Status First Login:"+status);
		return status;
	}
	public boolean LoginDAO(UserLoginBean userloginBean1) {
		// TODO Auto-generated method stub
		loadDriver(dbDriver);
	    Connection con =getConnection();
	    boolean status=false;
	    String sql="SELECT * FROM user where email=? and password= ?";
	    
	    PreparedStatement ps;
	    try {
	    	ps=con.prepareStatement(sql);
			ps.setString(1, userloginBean1.getUserId());
			ps.setString(2, userloginBean1.getNewPassword());
			
			ResultSet rs =ps.executeQuery();
//			System.out.println("Not a First Login"+rs.next());
			status=rs.next();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    System.out.println("Status Not First Login:"+status);
		return status;
	}	

}
