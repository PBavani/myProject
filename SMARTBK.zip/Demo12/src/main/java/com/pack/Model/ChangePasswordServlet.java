package com.pack.Model;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pack.Controller.UserLoginBean;
import com.pack.Dao.ChangePasswordDao;



@WebServlet("/ChangePasswordServlet")
public class ChangePasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String OldPassword=request.getParameter("OldPassword");
		String NewPassword=request.getParameter("NewPassword");
		String ConfirmPassword=request.getParameter("ConfirmPassword");
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		if(NewPassword.equals(ConfirmPassword)) {
			UserLoginBean userloginbean =new UserLoginBean();
			userloginbean.setOldPassword(OldPassword);
			userloginbean.setNewPassword(NewPassword);
			
			ChangePasswordDao changepassword=new ChangePasswordDao();
			int result=changepassword.ChangePasswordDAO(userloginbean);
			System.out.println("servlet :"+result);
			if(result>0) {
				RequestDispatcher rd=getServletContext().getRequestDispatcher("/bank1.jsp");
				rd.forward(request, response);
			}
			else {
				RequestDispatcher rd=getServletContext().getRequestDispatcher("/changepassword.jsp");
				rd.include(request,response);
			}
		}
		else {
			out.println("passwords doesnt match");
			RequestDispatcher rd=getServletContext().getRequestDispatcher("/changepassword.jsp");
			rd.include(request,response);
		}
	}

}
